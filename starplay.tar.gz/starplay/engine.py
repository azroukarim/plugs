import os
import json
import urllib.request
import urllib.error
import subprocess
import time
import ssl
from enigma import eTimer
from Screens.MessageBox import MessageBox
from Screens.InfoBar import MoviePlayer
from enigma import eServiceReference

RESUME_FILE = "/etc/enigma2/starplay_resume.json"

def load_resume_points():
    try:
        if os.path.exists(RESUME_FILE):
            with open(RESUME_FILE, "r") as f:
                return json.load(f)
    except:
        pass
    return {}

def save_resume_points(data):
    try:
        with open(RESUME_FILE, "w") as f:
            json.dump(data, f)
    except:
        pass

# Constants
TORR_PORT = 8090
TORR_BIN = "/usr/bin/TorrServer"
RELEASES_URL = "https://releases.yourok.ru/torr/server_release.json"

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

def get_arch():
    try:
        arch = subprocess.check_output('uname -m', shell=True).decode().strip()
        if 'armv7' in arch: return 'linux-arm7'
        if 'aarch64' in arch: return 'linux-arm64'
        if 'mips64' in arch: return 'linux-mips64le' # Enigma2 is mostly mipsel
        if 'mips' in arch: return 'linux-mipsle'
        if 'x86_64' in arch: return 'linux-amd64'
        if 'i686' in arch or 'i386' in arch: return 'linux-386'
        return 'linux-arm7' # Default fallback
    except:
        return 'linux-arm7'

def is_torrserver_running():
    try:
        req = urllib.request.Request(f"http://127.0.0.1:{TORR_PORT}/echo")
        res = urllib.request.urlopen(req, timeout=2, context=ctx)
        return res.getcode() == 200
    except:
        return False

def configure_torrserver():
    try:
        settings_url = f"http://127.0.0.1:{TORR_PORT}/settings"
        # 200MB cache size, aggressive read ahead
        data = {
            "action": "set",
            "sets": {
                "CacheSize": 209715200, 
                "ReaderReadAHead": 50,
                "PreloadCache": 50,
                "ForcePlay": True
            }
        }
        req = urllib.request.Request(settings_url, data=json.dumps(data).encode('utf-8'), headers={'Content-Type': 'application/json'})
        urllib.request.urlopen(req, timeout=3, context=ctx)
        print("[StarPlay] TorrServer configured with 200MB cache!")
    except Exception as e:
        print("[StarPlay] Error configuring TorrServer:", e)

def start_torrserver():
    if is_torrserver_running():
        configure_torrserver()
        return True
        
    if not os.path.exists(TORR_BIN):
        return False
        
    try:
        os.system(f"chmod +x {TORR_BIN}")
        os.system("export GODEBUG=madvdontneed=1")
        fh = open(os.devnull, 'wb')
        subprocess.Popen([TORR_BIN, '--port', str(TORR_PORT)], shell=False, stdout=fh, stderr=fh)
        time.sleep(2)
        if is_torrserver_running():
            configure_torrserver()
            return True
        return False
    except Exception as e:
        print(f"[StarPlay] Error starting TorrServer: {e}")
        return False

def download_torrserver(session, callback):
    def _download():
        try:
            # 1. Get latest release
            req = urllib.request.Request(RELEASES_URL, headers={'User-Agent': 'Mozilla/5.0'})
            res = urllib.request.urlopen(req, timeout=10, context=ctx)
            data = json.loads(res.read().decode('utf-8'))
            
            arch_key = get_arch()
            download_url = data.get('links', {}).get(arch_key)
            
            if not download_url:
                session.open(MessageBox, "TorrServer not available for your architecture.", MessageBox.TYPE_ERROR)
                return
                
            # 2. Download binary
            session.open(MessageBox, f"Downloading TorrServer engine...\nPlease wait...", MessageBox.TYPE_INFO, timeout=3)
            dl_req = urllib.request.Request(download_url, headers={'User-Agent': 'Mozilla/5.0'})
            dl_res = urllib.request.urlopen(dl_req, timeout=60, context=ctx)
            
            with open(TORR_BIN, 'wb') as f:
                f.write(dl_res.read())
                
            os.system(f"chmod +x {TORR_BIN}")
            
            # 3. Start
            if start_torrserver():
                callback()
            else:
                session.open(MessageBox, "Failed to start TorrServer.", MessageBox.TYPE_ERROR)
                
        except Exception as e:
            session.open(MessageBox, f"Error downloading engine: {str(e)}", MessageBox.TYPE_ERROR)
            
    # Run in background to avoid blocking GUI
    import threading
    t = threading.Thread(target=_download)
    t.start()

def play_magnet(session, magnet, title, imdb_id=None, season=None, episode=None):
    if not start_torrserver():
        session.openWithCallback(
            lambda res: download_torrserver(session, lambda: play_magnet(session, magnet, title, imdb_id, season, episode)) if res else None,
            MessageBox,
            "StarPlay needs to install the Torrent Engine (TorrServer) to play movies.\nSize is ~15MB.\nDo you want to install it now?",
            MessageBox.TYPE_YESNO
        )
        return

    from twisted.internet import threads
    
    def _start_playback():
        # 1. Add torrent
        add_url = f"http://127.0.0.1:{TORR_PORT}/torrents"
        add_data = json.dumps({"action": "add", "link": magnet, "title": title, "save_to_db": True}).encode('utf-8')
        add_req = urllib.request.Request(add_url, data=add_data, headers={'Content-Type': 'application/json'})
        add_res = urllib.request.urlopen(add_req, timeout=10, context=ctx)
        torrent_info = json.loads(add_res.read().decode('utf-8'))
        
        torrent_hash = torrent_info.get("hash")
        if not torrent_hash:
            raise Exception("Failed to add torrent.")
            
        # 2. Wait for metadata to fetch
        stream_url = ""
        for _ in range(45): # increased to 45 seconds for slow torrents
            time.sleep(1)
            stat_url = f"http://127.0.0.1:{TORR_PORT}/torrents"
            stat_data = json.dumps({"action": "list"}).encode('utf-8')
            stat_req = urllib.request.Request(stat_url, data=stat_data, headers={'Content-Type': 'application/json'})
            stat_res = urllib.request.urlopen(stat_req, timeout=5, context=ctx)
            all_torrents = json.loads(stat_res.read().decode('utf-8'))
            
            my_tor = next((t for t in all_torrents if t.get("hash") == torrent_hash), None)
            if my_tor and my_tor.get("file_stats"):
                files = my_tor["file_stats"]
                # Find largest video file
                video_files = [f for f in files if f.get("path", "").endswith(('.mp4', '.mkv', '.avi'))]
                biggest_file = None
                
                if season is not None and episode is not None and video_files:
                    import re
                    ep_pattern = re.compile(rf's{int(season):02d}e{int(episode):02d}|{int(season)}x{int(episode):02d}|episode[._-]?{int(episode)}', re.IGNORECASE)
                    matched = [f for f in video_files if ep_pattern.search(f.get("path", ""))]
                    if matched:
                        biggest_file = max(matched, key=lambda f: f.get("length", 0))
                        
                if not biggest_file:
                    if video_files:
                        biggest_file = max(video_files, key=lambda f: f.get("length", 0))
                    else:
                        biggest_file = max(files, key=lambda f: f.get("length", 0))
                    
                file_id = biggest_file.get("id", 1)
                # Keep slashes intact so Enigma2 detects .mkv/.mp4 extension
                file_path = urllib.parse.quote(biggest_file.get("path", "video.mp4").encode('utf-8'), safe='/')
                stream_url = f"http://127.0.0.1:{TORR_PORT}/stream/{file_path}?link={torrent_hash}&index={file_id}&play"
                break
                
        if not stream_url:
            raise Exception("Timeout waiting for torrent metadata. Seeders might be zero.")
            
        return stream_url

    def on_success(stream_url):
        class TorrPlayer(MoviePlayer):
            def __init__(self, session, ref, resume_pts=0, movie_title=""):
                MoviePlayer.__init__(self, session, ref)
                self.skinName = "MoviePlayer"
                self.resume_pts = resume_pts
                self.movie_title = movie_title
                
                from Components.ActionMap import ActionMap
                self["StarPlayExitActions"] = ActionMap(["SetupActions", "InfobarActions", "MoviePlayerActions"], {
                    "cancel": self.force_exit,
                    "stop": self.force_exit,
                    "leavePlayer": self.force_exit
                }, -1)
                
                self.seek_timer = eTimer()
                try:
                    self.seek_timer.callback.append(self.do_resume)
                except:
                    self.seek_timer_conn = self.seek_timer.timeout.connect(self.do_resume)
                self.seek_timer.start(500, True)
                
            def do_resume(self):
                if self.resume_pts > 0:
                    from enigma import iPlayableService
                    service = self.session.nav.getCurrentService()
                    if service:
                        seekable = service.seek()
                        if seekable:
                            seekable.seekTo(self.resume_pts)

            def save_resume_point(self):
                try:
                    from enigma import iPlayableService
                    service = self.session.nav.getCurrentService()
                    if service:
                        seekable = service.seek()
                        if seekable:
                            pts = seekable.getPlayPosition()
                            length = seekable.getLength()
                            if pts and len(pts) > 1 and length and len(length) > 1:
                                current_pts = pts[1]
                                total_pts = length[1]
                                # Only save if watched more than 1 min and not in last 3 mins
                                if current_pts > 90000 * 60 and current_pts < total_pts - (90000 * 180):
                                    resumes = load_resume_points()
                                    resumes[self.movie_title] = current_pts
                                    save_resume_points(resumes)
                except Exception as e:
                    print("[StarPlay] save_resume_point Error:", e)

            def force_exit(self):
                self.save_resume_point()
                self.session.nav.stopService()
                self.close()

            def leavePlayer(self):
                self.force_exit()
                
            def leavePlayerConfirmed(self, answer):
                self.force_exit()
                
            def doEofInternal(self, playing):
                resumes = load_resume_points()
                if self.movie_title in resumes:
                    del resumes[self.movie_title]
                    save_resume_points(resumes)
                self.session.nav.stopService()
                self.close()
                
        def do_open():
            try:
                player_type = 4097
                if os.path.exists("/usr/bin/exteplayer3"):
                    player_type = 5002
                
                ref = eServiceReference(player_type, 0, stream_url)
                ref.setName(title)
                
                resumes = load_resume_points()
                saved_pts = resumes.get(title, 0)
                
                def start_player(pts):
                    session.open(TorrPlayer, ref, pts, title)

                if saved_pts > 0:
                    def resume_answer(answer):
                        if answer:
                            start_player(saved_pts)
                        else:
                            start_player(0)
                    session.openWithCallback(resume_answer, MessageBox, _("Do you want to resume playback from where you left off?"), MessageBox.TYPE_YESNO)
                else:
                    start_player(0)
                    
            except Exception as e:
                print(f"StarPlay: Error opening player - {e}")
                err_str = traceback.format_exc()
                with open("/tmp/StarPlay_error.log", "w") as f:
                    f.write(err_str)
                session.open(MessageBox, f"TorrPlayer init error: {e}\nSee /tmp/StarPlay_error.log", MessageBox.TYPE_ERROR)
                
        # Store timer as attribute so it doesn't get garbage collected
        session._StarPlay_timer = eTimer()
        try:
            session._StarPlay_timer.callback.append(do_open)
        except Exception:
            session._StarPlay_timer_conn = session._StarPlay_timer.timeout.connect(do_open)
        session._StarPlay_timer.start(100, True)
        
    def on_error(failure):
        def do_err():
            session.open(MessageBox, f"Download thread error: {str(failure.getErrorMessage())}", MessageBox.TYPE_ERROR)
            
        session._StarPlay_timer_err = eTimer()
        try:
            session._StarPlay_timer_err.callback.append(do_err)
        except Exception:
            session._StarPlay_timer_err_conn = session._StarPlay_timer_err.timeout.connect(do_err)
        session._StarPlay_timer_err.start(100, True)

    threads.deferToThread(_start_playback).addCallback(on_success).addErrback(on_error)
