# StarPlay Enigma2 Plugin
__version__ = "2.1"
