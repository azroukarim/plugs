import os
import json
import urllib.request
import urllib.parse
import ssl

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

def log_debug(msg):
    try:
        with open("/tmp/StarPlay_subs.log", "a") as f:
            f.write(msg + "\n")
    except:
        pass

# Language mapping from 2-letter to 3-letter (Stremio API)
LANG_MAP = {
    'ar': 'ara',
    'en': 'eng',
    'fr': 'fre',
    'es': 'spa',
    'de': 'ger',
    'it': 'ita',
    'pt': 'por',
    'nl': 'nld',
    'tr': 'tur',
    'ru': 'rus'
}

API_KEY_PATH = "/etc/enigma2/subapi-key/api-key.txt"

def get_api_key():
    try:
        if os.path.exists(API_KEY_PATH):
            with open(API_KEY_PATH, "r") as f:
                return f.read().strip()
    except Exception:
        pass
    return None

def download_stremio(imdb_id, title, lang):
    stremio_lang = LANG_MAP.get(lang, 'eng')
    log_debug(f"[Stremio] Searching for {stremio_lang}")
    search_url = f"https://opensubtitles-v3.strem.io/subtitles/movie/{imdb_id}.json"
    
    try:
        req = urllib.request.Request(search_url, headers={'User-Agent': 'Mozilla/5.0'})
        res = urllib.request.urlopen(req, timeout=10, context=ctx)
        data = json.loads(res.read().decode('utf-8'))
        
        subs_list = data.get('subtitles', [])
        matched_subs = [s for s in subs_list if s.get('lang') == stremio_lang]
        if not matched_subs:
            return None
            
        srt_link = matched_subs[0].get('url')
        if not srt_link:
            return None
            
        clean_title = "".join(x for x in title if x.isalnum() or x in " -_")
        srt_path = f"/tmp/{clean_title}.srt"
        
        req_srt = urllib.request.Request(srt_link, headers={'User-Agent': 'Mozilla/5.0'})
        res_srt = urllib.request.urlopen(req_srt, timeout=10, context=ctx)
        
        with open(srt_path, 'wb') as f:
            f.write(res_srt.read())
            
        log_debug(f"[Stremio] Success: {srt_path}")
        return srt_path
    except Exception as e:
        log_debug(f"[Stremio] Error: {e}")
        return None

def download_opensubtitles(imdb_id, title, lang):
    api_key = get_api_key()
    if not api_key:
        log_debug("[OpenSubtitles] No API key found.")
        return None
        
    clean_imdb_id = imdb_id.replace('tt', '')
    search_url = f"https://api.opensubtitles.com/api/v1/subtitles?imdb_id={clean_imdb_id}&languages={lang}"
    log_debug(f"[OpenSubtitles] Searching for {lang}")
    
    try:
        req = urllib.request.Request(search_url, headers={
            'Api-Key': api_key,
            'User-Agent': 'StarPlay v1',
            'Accept': 'application/json'
        })
        res = urllib.request.urlopen(req, timeout=10, context=ctx)
        data = json.loads(res.read().decode('utf-8'))
        
        if not data.get('data'):
            return None
            
        file_id = data['data'][0]['attributes']['files'][0]['file_id']
        download_url = "https://api.opensubtitles.com/api/v1/download"
        post_data = json.dumps({"file_id": file_id}).encode('utf-8')
        
        req_dl = urllib.request.Request(download_url, data=post_data, headers={
            'Api-Key': api_key,
            'User-Agent': 'StarPlay v1',
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        })
        res_dl = urllib.request.urlopen(req_dl, timeout=10, context=ctx)
        dl_data = json.loads(res_dl.read().decode('utf-8'))
        
        srt_link = dl_data.get('link')
        if not srt_link:
            return None
            
        clean_title = "".join(x for x in title if x.isalnum() or x in " -_")
        srt_path = f"/tmp/{clean_title}.srt"
        
        req_srt = urllib.request.Request(srt_link, headers={'User-Agent': 'StarPlay v1'})
        res_srt = urllib.request.urlopen(req_srt, timeout=10, context=ctx)
        
        with open(srt_path, 'wb') as f:
            f.write(res_srt.read())
            
        log_debug(f"[OpenSubtitles] Success: {srt_path}")
        return srt_path
    except Exception as e:
        log_debug(f"[OpenSubtitles] Error: {e}")
        return None

def download_subtitle(imdb_id, title, lang="ar"):
    log_debug(f"--- Fetching {lang} subtitle for {title} ({imdb_id}) ---")
    
    # Provider 1: Stremio
    srt_path = download_stremio(imdb_id, title, lang)
    if srt_path:
        return srt_path, lang
        
    # Provider 2: OpenSubtitles Official API
    srt_path = download_opensubtitles(imdb_id, title, lang)
    if srt_path:
        return srt_path, lang
        
    # Fallback to English if not searching for English
    if lang != "en":
        log_debug("--- Falling back to English ---")
        srt_path = download_stremio(imdb_id, title, "en")
        if srt_path:
            return srt_path, "en"
        srt_path = download_opensubtitles(imdb_id, title, "en")
        if srt_path:
            return srt_path, "en"
            
    log_debug("--- No subtitles found anywhere ---")
    return None, None
