# pyrefly: ignore [missing-import]
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.MenuList import MenuList
from enigma import eTimer, ePicLoad, eServiceReference, eSize, ePoint
from Tools.LoadPixmap import LoadPixmap
from Screens.MessageBox import MessageBox
from Screens.InfoBar import MoviePlayer
from .api import fetch_tmdb, TMDB_API_KEY
from .downloader import download_image, clear_cache
from .scraper import get_stream_url
import ssl
import urllib.request
import urllib.parse
import json

# Initialize SSL at module level to avoid Enigma2 thread segfaults
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

class MovieDetailsScreen(Screen):
    def __init__(self, session, movie, media_type):
        self.movie = movie
        self.media_type = media_type
        
        self.skin = """
            <screen name="MovieDetailsScreen" position="center,center" size="1920,1080" title="Movie Details" backgroundColor="#101010" flags="wfNoBorder">
                <!-- Full Screen Backdrop -->
                <widget name="backdrop" position="0,0" size="1920,1080" zPosition="-3" alphatest="blend" scale="1" />
                
                <!-- Text Content (Bottom Left) -->
                <widget name="title" position="50,550" size="1800,100" font="Regular;75" halign="left" foregroundColor="#FFFFFF" shadowColor="#000000" shadowOffset="3,3" transparent="1" />
                <widget name="rating" position="50,670" size="250,50" font="Regular;35" halign="left" foregroundColor="#FFD700" shadowColor="#000000" shadowOffset="2,2" transparent="1" />
                <widget name="year" position="300,670" size="850,50" font="Regular;35" halign="left" foregroundColor="#AAAAAA" shadowColor="#000000" shadowOffset="2,2" transparent="1" />
                <widget name="overview" position="50,740" size="1600,150" font="Regular;32" halign="left" valign="top" foregroundColor="#DDDDDD" shadowColor="#000000" shadowOffset="2,2" transparent="1" />
                
                <!-- Play Button -->
                <eLabel position="50,920" size="280,60" backgroundColor="#00FFFFFF" zPosition="0" />
                <widget name="btn_play" position="50,920" size="280,60" font="Regular;35" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#00FFFFFF" transparent="1" zPosition="1" />
            </screen>
        """
        Screen.__init__(self, session)
        
        title_str = movie.get('title', '')
        self["title"] = Label(title_str)
        self["rating"] = Label(f"★ {movie.get('vote_average', 'N/A')}")
        self["year"] = Label(f"{movie.get('year', 'N/A')}")
        self["overview"] = Label(movie.get('overview', 'No overview available.'))
        self["btn_play"] = Label("▶ Play (OK)")
        
        self["backdrop"] = Pixmap()
        
        self["actions"] = ActionMap(["SetupActions", "ColorActions", "OkCancelActions"], {
            "ok": self.play,
            "cancel": self.close
        }, -1)
        
        self.onLayoutFinish.append(self.load_images)
        
    def load_images(self):
        backdrop_url = self.movie.get('backdrop')
        if backdrop_url:
            dest_bd = "/tmp/detail_backdrop.jpg"
            from .downloader import download_image
            download_image(backdrop_url, dest_bd, callback=self.backdrop_loaded)

    def backdrop_loaded(self, path):
        import os
        from Tools.LoadPixmap import LoadPixmap
        if os.path.exists(path):
            ptr = LoadPixmap(path)
            if ptr is not None:
                self["backdrop"].instance.setPixmap(ptr)
                
    def play(self):
        title = self.movie['title']
        imdb_id = self.movie.get('imdb_id', '')
        
        if self.media_type == "tv":
            tmdb_id = self.movie.get('tmdb_id')
            if not tmdb_id:
                self.session.open(MessageBox, _("No TMDB ID found for this series."), MessageBox.TYPE_ERROR)
                return
            from .ui import TVShowBrowser
            self.session.open(TVShowBrowser, title, imdb_id, tmdb_id)
            self.close()
            return
            
        if not imdb_id:
            self.session.open(MessageBox, _("No IMDb ID found for this selection."), MessageBox.TYPE_ERROR)
            return
            
        self.session.open(MessageBox, _("Searching for High Quality Stream..."), MessageBox.TYPE_INFO, timeout=3)
        
        from twisted.internet import threads
        def _fetch_all_streams():
            """Collect ALL available streams and return list for user to choose."""
            all_streams = []
            seen_hashes = set()
            
            # === SOURCE 1: Torrentio (aggregates from all providers) ===
            torrentio_urls = [
                f"https://torrentio.strem.fun/providers=yts,eztv,rarbg,1337x,thepiratebay,kickass/sort=seeders/stream/movie/{imdb_id}.json",
                f"https://torrentio.strem.fun/sort=seeders/stream/movie/{imdb_id}.json",
                f"https://torrentio.strem.fun/stream/movie/{imdb_id}.json",
            ]
            
            for torrentio_url in torrentio_urls:
                try:
                    req = urllib.request.Request(torrentio_url, headers={
                        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36',
                        'Accept': 'application/json',
                        'Accept-Language': 'en-US,en;q=0.9'
                    })
                    res = urllib.request.urlopen(req, timeout=15, context=ctx)
                    data = json.loads(res.read().decode('utf-8'))
                    streams = data.get('streams', [])
                    
                    for stream in streams:
                        info_hash = stream.get('infoHash', '')
                        direct_url = stream.get('url', '')
                        name = stream.get('name', '').strip()
                        stream_title = stream.get('title', '').strip()
                        
                        # Parse quality from name/title
                        label_parts = []
                        for quality in ['4K', '2160p', '1080p', '720p', '480p', '360p']:
                            if quality.lower() in (name + stream_title).lower():
                                label_parts.append(quality)
                                break
                        
                        # Source name
                        source = name.split('\n')[0] if '\n' in name else name[:15]
                        if not source:
                            source = 'Unknown'
                            
                        # Size/seeds from title
                        size_info = ''
                        for line in stream_title.split('\n'):
                            if '👤' in line or 'GB' in line or 'MB' in line:
                                size_info = line.strip()[:30]
                                break
                        
                        quality_label = label_parts[0] if label_parts else '?p'
                        
                        # Detect French and Arabic
                        is_french = False
                        is_arabic = False
                        upper_title = stream_title.upper().replace('/', ' ').replace('.', ' ').replace('-', ' ')
                        
                        import re
                        if re.search(r'\b(FRENCH|TRUEFRENCH|VFF|VFI|VF|MULTI)\b', upper_title) or '🇫🇷' in stream_title:
                            is_french = True
                        if re.search(r'\b(ARABIC|MULTI SUBS|MULTISUB|AR|ARAB)\b', upper_title) or '🇦🇪' in stream_title:
                            is_arabic = True
                            
                        display = f"{quality_label} | {source} | {size_info}" if size_info else f"{quality_label} | {source}"
                        
                        prefix = ""
                        if is_arabic and is_french:
                            prefix = "🇦🇪 AR/🇫🇷 VF | "
                        elif is_arabic:
                            prefix = "🇦🇪 AR/🇬🇧 EN | "
                        elif is_french:
                            prefix = "🇫🇷 VF | "
                            
                        display = prefix + display
                        
                        if info_hash and info_hash not in seen_hashes:
                            seen_hashes.add(info_hash)
                            trackers = "tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337&tr=udp%3A%2F%2Fopen.tracker.cl%3A1337&tr=udp%3A%2F%2Fp4p.arenabg.com%3A1337"
                            # Add specific trackers from Stremio stream
                            stream_sources = stream.get('sources', [])
                            for src in stream_sources:
                                if src.startswith("tracker:"):
                                    trk_url = src.replace("tracker:", "")
                                    trackers += f"&tr={urllib.parse.quote(trk_url)}"
                            magnet = f"magnet:?xt=urn:btih:{info_hash}&dn={urllib.parse.quote(title)}&{trackers}"
                            all_streams.append({'label': display, 'magnet': magnet, 'quality': quality_label})
                        elif direct_url and direct_url.startswith('http') and direct_url not in seen_hashes:
                            seen_hashes.add(direct_url)
                            all_streams.append({'label': display, 'magnet': direct_url, 'quality': quality_label})
                    
                    if all_streams:
                        break  # Got results, no need to try next URL
                except Exception:
                    continue
                    
            # === SOURCE 1.5: Explicit French Audio Search (TPB) ===
            if self.media_type != "tv":
                try:
                    clean_title = title.split('(')[0].strip()
                    fr_queries = [f"{clean_title} FRENCH", f"{clean_title} TRUEFRENCH"]
                    for fq in fr_queries:
                        req = urllib.request.Request(
                            f"https://apibay.org/q.php?q={urllib.parse.quote(fq)}",
                            headers={'User-Agent': 'Mozilla/5.0'}
                        )
                        res = urllib.request.urlopen(req, timeout=5, context=ctx)
                        items = json.loads(res.read().decode('utf-8'))
                        if items and isinstance(items, list):
                            for item in items:
                                h = item.get('info_hash', '')
                                if h and h != '0000000000000000000000000000000000000000' and h not in seen_hashes:
                                    seen_hashes.add(h)
                                    item_name = item.get('name', 'Unknown')[:50]
                                    size_bytes = int(item.get('size', 0))
                                    size_gb = f"{size_bytes/1024/1024/1024:.1f}GB" if size_bytes > 0 else ''
                                    quality = '?p'
                                    for q_label in ['4K', '2160p', '1080p', '720p', '480p']:
                                        if q_label.lower() in item_name.lower():
                                            quality = q_label
                                            break
                                    display = f"🇫🇷 VF | {quality} | TPB-FR | {size_gb}"
                                    magnet = f"magnet:?xt=urn:btih:{h}&dn={urllib.parse.quote(item_name)}&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337"
                                    all_streams.append({'label': display, 'magnet': magnet, 'quality': quality})
                                    if len(all_streams) >= 15: # Prevent overloading the list
                                        break
                except Exception:
                    pass
                    
            # === SOURCE 2: YTS API (High Quality Direct Movie Torrents) ===
            if not all_streams and self.media_type != "tv" and imdb_id:
                try:
                    req = urllib.request.Request(
                        f"https://yts.mx/api/v2/list_movies.json?query_term={imdb_id}",
                        headers={'User-Agent': 'Mozilla/5.0'}
                    )
                    res = urllib.request.urlopen(req, timeout=10, context=ctx)
                    yts_data = json.loads(res.read().decode('utf-8'))
                    if yts_data.get('status') == 'ok' and yts_data.get('data', {}).get('movie_count', 0) > 0:
                        movies_list = yts_data['data']['movies']
                        for m in movies_list:
                            for t in m.get('torrents', []):
                                h = t.get('hash', '')
                                if h and h not in seen_hashes:
                                    seen_hashes.add(h)
                                    quality = t.get('quality', '?p')
                                    size = t.get('size', '')
                                    display = f"{quality} | YTS | {size}"
                                    trackers = "tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337&tr=udp%3A%2F%2Fopen.tracker.cl%3A1337&tr=udp%3A%2F%2Fp4p.arenabg.com%3A1337"
                                    magnet = f"magnet:?xt=urn:btih:{h}&dn={urllib.parse.quote(title)}&{trackers}"
                                    all_streams.append({'label': display, 'magnet': magnet, 'quality': quality})
                except Exception:
                    pass
                    
            # === SOURCE 3: apibay fallback ===
            if not all_streams:
                clean_title = title.split('(')[0].strip()
                for q in [imdb_id, urllib.parse.quote(clean_title)]:
                    if not q:
                        continue
                    try:
                        req = urllib.request.Request(
                            f"https://apibay.org/q.php?q={q}",
                            headers={'User-Agent': 'Mozilla/5.0'}
                        )
                        res = urllib.request.urlopen(req, timeout=8, context=ctx)
                        items = json.loads(res.read().decode('utf-8'))
                        if items and isinstance(items, list):
                            for item in items:
                                h = item.get('info_hash', '')
                                if h and h != '0000000000000000000000000000000000000000' and h not in seen_hashes:
                                    seen_hashes.add(h)
                                    item_name = item.get('name', 'Unknown')[:50]
                                    size_bytes = int(item.get('size', 0))
                                    size_gb = f"{size_bytes/1024/1024/1024:.1f}GB" if size_bytes > 0 else ''
                                    # Extract quality
                                    quality = '?p'
                                    for q_label in ['4K', '2160p', '1080p', '720p', '480p']:
                                        if q_label.lower() in item_name.lower():
                                            quality = q_label
                                            break
                                    display = f"{quality} | TPB | {size_gb}"
                                    magnet = f"magnet:?xt=urn:btih:{h}&dn={urllib.parse.quote(title)}&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337"
                                    all_streams.append({'label': display, 'magnet': magnet, 'quality': quality})
                                    if len(all_streams) >= 10:
                                        break
                        if all_streams:
                            break
                    except Exception:
                        continue
                        
            # Sort final list to prioritize AR and VF
            def get_priority(stream):
                label = stream.get('label', '')
                if '🇦🇪' in label and '🇫🇷' in label:
                    return 0 # Both AR and VF
                elif '🇦🇪' in label:
                    return 1 # AR only
                elif '🇫🇷' in label:
                    return 2 # VF only
                return 3 # Normal
                
            all_streams.sort(key=get_priority)
            return all_streams
            
        def on_fetch_success(streams):
            if not streams:
                self.session.open(MessageBox, _(
                    f'"{title}" not found.\n'
                    'The film may be too new or not yet available.\n'
                    'Try another movie.'
                ), MessageBox.TYPE_INFO)
                return
                
            from .ui import QualitySelectScreen
            self.session.open(QualitySelectScreen, streams, title, imdb_id)
            
        def on_fetch_error(failure):
            self.session.open(MessageBox, _(f"Error: {str(failure.getErrorMessage())}"), MessageBox.TYPE_ERROR)
            
        threads.deferToThread(_fetch_all_streams).addCallback(on_fetch_success).addErrback(on_fetch_error)

class StarPlayGridScreen(Screen):
    # Base skin for 1920x1080 with grid items
    skin = """
    <screen position="center,center" size="1920,1080" title="StarPlay Grid" backgroundColor="#101010" flags="wfNoBorder">
        
        <!-- Header -->
        <widget name="header_title" position="50,30" size="1000,50" font="Regular;40" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" />
        <widget name="page_info" position="1670,30" size="200,50" font="Regular;35" halign="right" valign="center" foregroundColor="#aaaaaa" transparent="1" />
        
        <!-- Top Categories Bar -->
        <widget name="btn_red_bg" pixmap="skin_default/buttons/red.png" position="300,35" size="30,30" alphatest="on" />
        <widget name="key_red" position="340,30" size="250,40" font="Regular;30" halign="left" valign="center" foregroundColor="#ff0000" transparent="1" />
        
        <ePixmap pixmap="skin_default/buttons/yellow.png" position="600,35" size="30,30" alphatest="on" />
        <widget name="key_yellow" position="640,30" size="200,40" font="Regular;30" halign="left" valign="center" foregroundColor="#ffff00" transparent="1" />
        
        <ePixmap pixmap="skin_default/buttons/blue.png" position="900,35" size="30,30" alphatest="on" />
        <widget name="key_blue" position="940,30" size="200,40" font="Regular;30" halign="left" valign="center" foregroundColor="#0088ff" transparent="1" />
        
        <widget name="loading_info" position="0,500" size="1920,80" font="Regular;45" halign="center" valign="center" foregroundColor="#ffff00" transparent="1" zPosition="10"/>
        
        <!-- Selection border (Yellow background to highlight) -->
        <widget name="selector" position="130,70" size="180,260" backgroundColor="#ffff00" zPosition="0" />
        
        {grid_xml}
        
        <!-- Movie info footer -->
        <widget name="movie_title" position="50,900" size="1820,50" font="Regular;45" halign="center" foregroundColor="#ffffff" transparent="1" />
        <widget name="movie_desc" position="50,960" size="1820,100" font="Regular;30" halign="center" valign="top" foregroundColor="#cccccc" transparent="1" />
    </screen>
    """
    
    def __init__(self, session, media_type="movie"):
        Screen.__init__(self, session)
        self.media_type = media_type
        
        # Grid parameters
        self.cols = 7
        self.rows = 2
        self.total_items = self.cols * self.rows
        
        # Build XML dynamically
        grid_xml = ""
        for i in range(self.total_items):
            x = 140 + (i % self.cols) * 240
            y = 80 + (i // self.cols) * 360
            grid_xml += f'<widget name="poster_{i}" position="{x},{y}" size="160,240" alphatest="on" scale="1" zPosition="1" />\n'
            grid_xml += f'<widget name="title_{i}" position="{x-20},{y+245}" size="200,60" font="Regular;24" halign="center" valign="top" foregroundColor="#ffffff" transparent="1" zPosition="2" />\n'
            
        self.skin = self.skin.replace("{grid_xml}", grid_xml)
        
        self.movies = []
        self.page = 1
        self.current_idx = 0
        self.category = "latest" # latest or popular
        
        self.genre_id = None
        self.genre_name = "All"
        
        self.update_available = False
        self.new_version = ""
        self.changelog = ""
        
        self["header_title"] = Label("StarPlay")
        self["page_info"] = Label("Page: 1")
        self["loading_info"] = Label("Loading...")
        
        self["key_yellow"] = Label(_("Popular / Latest"))
        self["key_blue"] = Label(_("Genres"))
        self["key_red"] = Label("")
        self["btn_red_bg"] = Pixmap()
        
        self["movie_title"] = Label("")
        self["movie_desc"] = Label("")
        self["selector"] = Label("")
        
        for i in range(15):
            self[f"poster_{i}"] = Pixmap()
            self[f"title_{i}"] = Label("")
            
        self["actions"] = ActionMap(["SetupActions", "DirectionActions", "ColorActions", "ChannelSelectEPGActions"],
        {
            "ok": self.playSelected,
            "cancel": self.closeUI,
            "red": self.onRedPress,
            "green": self.playSelected,
            "yellow": self.toggleSort,
            "blue": self.openGenreSelect,
            "menu": self.openSettings,
            "left": self.moveLeft,
            "right": self.moveRight,
            "up": self.moveUp,
            "down": self.moveDown,
            "nextBouquet": self.pageNext,
            "prevBouquet": self.pagePrev
        }, -1)
        
        self.onLayoutFinish.append(self.startLoading)
        self.onLayoutFinish.append(self.checkForUpdates)

    def checkForUpdates(self):
        self["btn_red_bg"].hide()
        
        def _check():
            try:
                import os, urllib.request, ssl
                ctx = ssl.create_default_context()
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
                
                # Load local version
                local_ver = "v3.0"
                v_file = "/usr/lib/enigma2/python/Plugins/Extensions/StarPlay/version.txt"
                if os.path.exists(v_file):
                    with open(v_file, "r") as f:
                        lines = f.read().strip().split("\n")
                        if lines: local_ver = lines[0].strip()
                elif os.path.exists(os.path.join(os.path.dirname(__file__), "version.txt")):
                    with open(os.path.join(os.path.dirname(__file__), "version.txt"), "r") as f:
                        lines = f.read().strip().split("\n")
                        if lines: local_ver = lines[0].strip()
                        
                # Fetch remote version.txt
                url = "https://raw.githubusercontent.com/azroukarim/plugs/refs/heads/main/starplay/version.txt"
                req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
                res = urllib.request.urlopen(req, timeout=5, context=ctx)
                remote_text = res.read().decode('utf-8').strip()
                
                if not remote_text:
                    return {"update": False}
                    
                lines = remote_text.split("\n")
                remote_ver = lines[0].strip()
                remote_changelog = "\n".join(lines[1:]).strip() if len(lines) > 1 else "Bug fixes and improvements."
                
                if remote_ver and remote_ver.lower() != "none" and remote_ver != local_ver:
                    return {"update": True, "ver": remote_ver, "log": remote_changelog}
            except Exception:
                pass
            return {"update": False}
            
        def _on_check(res):
            if res and res.get("update"):
                self.update_available = True
                self.new_version = res.get("ver")
                self.changelog = res.get("log")
                self["key_red"].setText(_("Update Available"))
                self["btn_red_bg"].show()
                
        from twisted.internet import threads
        threads.deferToThread(_check).addCallback(_on_check)
        
    def onRedPress(self):
        if self.update_available:
            from .update import StarPlayUpdateScreen
            self.session.open(StarPlayUpdateScreen, self.new_version, self.changelog)
        else:
            self.closeUI()

    def closeUI(self):
        self.close()

    def toggleSort(self):
        if self.category == "latest":
            self.category = "popular"
        else:
            self.category = "latest"
        self.page = 1
        self.current_idx = 0
        self.updateHeader()
        self.startLoading()

    def openGenreSelect(self):
        from .ui import GenreSelectScreen
        self.session.openWithCallback(self.onGenreSelected, GenreSelectScreen, self.media_type)

    def onGenreSelected(self, genre_id=None, genre_name=None):
        if genre_name is not None:
            self.genre_id = genre_id
            self.genre_name = genre_name
            self.page = 1
            self.current_idx = 0
            self.updateHeader()
            self.startLoading()

    def openSettings(self):
        try:
            from .settings import StarPlaySettingsScreen
            self.session.open(StarPlaySettingsScreen)
        except Exception as e:
            print(f"StarPlay: Error opening settings {e}")

    def updateHeader(self):
        mtype_str = _("Movies") if self.media_type == "movie" else _("Series")
        cat_str = _("Popular") if self.category == "popular" else _("Latest")
        genre_str = f" - {self.genre_name}" if self.genre_id else ""
        self["header_title"].setText(f"StarPlay - {mtype_str} ({cat_str}){genre_str}")

    def startLoading(self):
        clear_cache()
        self["loading_info"].setText(_("Loading... Please wait"))
        self["page_info"].setText(f"Page: {self.page}")
        self.movies = []
        self.updateGrid()
        
        from twisted.internet import threads
        
        def worker():
            return fetch_tmdb(self.media_type, self.category, self.page, self.genre_id)
            
        def on_success(result):
            self.movies = result
            if not self.movies:
                self["loading_info"].setText(_("Error fetching data."))
            else:
                first_title = self.movies[0].get('title', '')
                if first_title.startswith("ERROR:"):
                    self["loading_info"].setText(first_title)
                else:
                    self["loading_info"].setText("")
            self.updateGrid()
            
        def on_error(failure):
            self.movies = [{"title": f"ERROR: {str(failure.getErrorMessage())}", "imdb_id": "", "poster": ""}]
            self["loading_info"].setText(self.movies[0]["title"])
            self.updateGrid()
            
        threads.deferToThread(worker).addCallback(on_success).addErrback(on_error)

    def updateGrid(self):
        for i in range(15):
            if i < len(self.movies):
                movie = self.movies[i]
                if not movie['title'].startswith("ERROR:"):
                    self[f"title_{i}"].setText(movie.get('display_title', movie['title']))
                    poster_url = movie['poster']
                    dest = f"/tmp/poster_{i}.jpg"
                    if poster_url:
                        download_image(poster_url, dest, callback=self.posterLoaded)
                else:
                    self[f"title_{i}"].setText("")
            else:
                self[f"title_{i}"].setText("")
                self[f"poster_{i}"].hide()
                
        self.updateSelector()

    def posterLoaded(self, path):
        try:
            idx = int(path.split('_')[1].split('.')[0])
            self.showPoster(idx, path)
        except:
            pass

    def showPoster(self, idx, path):
        import os
        if idx < 15 and self[f"poster_{idx}"] and os.path.exists(path):
            ptr = LoadPixmap(path)
            if ptr is not None:
                self[f"poster_{idx}"].instance.setPixmap(ptr)
                self[f"poster_{idx}"].show()

    def updateSelector(self):
        if not self.movies or (len(self.movies) > 0 and self.movies[0]['title'].startswith("ERROR:")):
            self["selector"].hide()
            return
            
        self["selector"].show()
        row = self.current_idx // self.cols
        col = self.current_idx % self.cols
        x = self.start_x + (col * self.spacing_x) - 5
        y = self.start_y + (row * self.spacing_y) - 5
        self["selector"].instance.move(ePoint(int(x), int(y)))

    def moveLeft(self):
        if self.current_idx > 0:
            self.current_idx -= 1
            self.updateSelector()
        else:
            # First item, jump to prev page
            self.pagePrev()

    def moveRight(self):
        if self.current_idx < len(self.movies) - 1:
            self.current_idx += 1
            self.updateSelector()
        elif self.current_idx == 14:
            # Last item on page, jump to next page
            self.pageNext()

    def moveUp(self):
        if self.current_idx - self.cols >= 0:
            self.current_idx -= self.cols
            self.updateSelector()

    def moveDown(self):
        if self.current_idx + self.cols < len(self.movies):
            self.current_idx += self.cols
            self.updateSelector()

    def pageNext(self):
        self.page += 1
        self.current_idx = 0
        self.startLoading()

    def pagePrev(self):
        if self.page > 1:
            self.page -= 1
            self.current_idx = 0
            self.startLoading()

    def playSelected(self):
        if not self.movies or self.current_idx >= len(self.movies):
            return
            
        movie = self.movies[self.current_idx]
        if movie.get('title', '').startswith("ERROR:"): return
        
        self.session.open(MovieDetailsScreen, movie, self.media_type)

class QualitySelectScreen(Screen):
    skin = """
    <screen position="center,center" size="900,700" title="Select Quality" backgroundColor="#101010" flags="wfNoBorder">
        <widget name="title" position="20,20" size="860,60" font="Regular;40" halign="center" foregroundColor="#ffffff" transparent="1" zPosition="2" />
        <widget name="list" position="20,100" size="860,500" font="Regular;35" itemHeight="60" scrollbarMode="showOnDemand" transparent="1" zPosition="2" />
        <widget name="subtitle" position="20,620" size="860,50" font="Regular;30" halign="center" foregroundColor="#aaaaaa" transparent="1" zPosition="2" />
    </screen>
    """
    def __init__(self, session, streams, movie_title, imdb_id="", season=None, episode=None):
        Screen.__init__(self, session)
        self.streams = streams
        self.movie_title = movie_title
        self.imdb_id = imdb_id
        self.season = season
        self.episode = episode
        
        # Priority sorting:
        # 1. AR/VF
        # 2. AR/EN
        # 3. VF
        # 4. Others (sorted by quality 4K -> 1080 -> 720)
        def priority(s):
            label = s['label']
            p = 10
            if "🇦🇪 AR/🇫🇷 VF" in label:
                p = 1
            elif "🇦🇪 AR/🇬🇧 EN" in label:
                p = 2
            elif "🇫🇷 VF" in label:
                p = 3
                
            q_score = 4
            if "4K" in label or "2160" in label: q_score = 0
            elif "1080" in label: q_score = 1
            elif "720" in label: q_score = 2
            elif "480" in label: q_score = 3
            
            return (p, q_score)
            
        self.streams.sort(key=priority)
        
        self["title"] = Label(movie_title)
        self["list"] = MenuList([s['label'] for s in self.streams])
        self["subtitle"] = Label(_("Press OK to play, EXIT to cancel"))
        
        self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
            "ok": self.onSelect,
            "cancel": self.close,
        }, -1)
        
    def onSelect(self):
        idx = self["list"].getSelectedIndex()
        if idx == -1: return
        
        selected = self.streams[idx]
        magnet = selected['magnet']
        
        self["subtitle"].setText(_("Connecting to peers... Please wait..."))
        
        from .engine import play_magnet
        play_magnet(self.session, magnet, self.movie_title, self.imdb_id, self.season, self.episode)


class TVShowBrowser(Screen):
    skin = """
    <screen position="center,center" size="1920,1080" title="TV Show Browser" backgroundColor="#101010" flags="wfNoBorder">
        <widget name="poster" position="1150,150" size="650,850" alphatest="on" scale="1" zPosition="1" backgroundColor="#202020" />
        <widget name="title" position="50,50" size="1100,80" font="Regular;50" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="2" />
        <widget name="list" position="50,150" size="1050,850" font="Regular;40" itemHeight="60" scrollbarMode="showOnDemand" transparent="1" zPosition="2" />
        <widget name="loading" position="50,450" size="1050,100" font="Regular;40" halign="center" valign="center" foregroundColor="#ffff00" transparent="1" zPosition="10"/>
    </screen>
    """
    
    def __init__(self, session, show_title, imdb_id, tmdb_id):
        Screen.__init__(self, session)
        self.show_title = show_title
        self.imdb_id = imdb_id
        self.tmdb_id = tmdb_id
        
        self.state = "seasons" # "seasons" or "episodes"
        self.seasons = []
        self.episodes = []
        self.selected_season = None
        
        self["title"] = Label(f"{show_title} - Seasons")
        self["list"] = MenuList([])
        self["loading"] = Label("Loading Seasons...")
        self["poster"] = Pixmap()
        
        self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
            "ok": self.onSelect,
            "cancel": self.onCancel,
        }, -1)
        
        self.onLayoutFinish.append(self.loadSeasons)
        self["list"].onSelectionChanged.append(self.selectionChanged)
        
    def loadSeasons(self):
        from twisted.internet import threads
        from .api import fetch_seasons
        self["list"].hide()
        self["loading"].show()
        threads.deferToThread(fetch_seasons, self.tmdb_id).addCallback(self.onSeasonsLoaded).addErrback(self.onError)
        
    def onSeasonsLoaded(self, seasons):
        self["loading"].hide()
        self.seasons = seasons
        if not seasons:
            self.session.open(MessageBox, "No seasons found.", MessageBox.TYPE_ERROR)
            self.close()
            return
            
        list_items = [s['name'] for s in seasons]
        self["list"].setList(list_items)
        self["list"].show()
        self.selectionChanged()
        
    def selectionChanged(self):
        idx = self["list"].getSelectedIndex()
        if idx == -1: return
        
        poster_url = ""
        if self.state == "seasons" and self.seasons and idx < len(self.seasons):
            poster_url = self.seasons[idx].get('poster')
        elif self.state == "episodes" and self.episodes and idx < len(self.episodes):
            poster_url = self.episodes[idx].get('still')
            
        if poster_url:
            from .downloader import download_image
            import os
            # Delete old poster to force refresh
            if os.path.exists("/tmp/tv_poster.jpg"):
                try: os.remove("/tmp/tv_poster.jpg")
                except: pass
                
            download_image(poster_url, "/tmp/tv_poster.jpg", self.showPoster)
            
    def showPoster(self, path):
        import os
        if path and os.path.exists(path):
            ptr = LoadPixmap(path)
            if ptr is not None:
                self["poster"].instance.setPixmap(ptr)
                self["poster"].show()
        
    def loadEpisodes(self, season_num):
        from twisted.internet import threads
        from .api import fetch_episodes
        self.state = "episodes"
        self.selected_season = season_num
        self["title"].setText(f"{self.show_title} - Season {season_num} Episodes")
        self["list"].hide()
        self["loading"].show()
        threads.deferToThread(fetch_episodes, self.tmdb_id, season_num).addCallback(self.onEpisodesLoaded).addErrback(self.onError)
        
    def onEpisodesLoaded(self, episodes):
        self["loading"].hide()
        self.episodes = episodes
        if not episodes:
            self.session.open(MessageBox, "No episodes found.", MessageBox.TYPE_ERROR)
            self.state = "seasons"
            self["title"].setText(f"{self.show_title} - Seasons")
            self["list"].setList([s['name'] for s in self.seasons])
            self["list"].show()
            return
            
        list_items = [e['name'] for e in episodes]
        self["list"].setList(list_items)
        self["list"].show()
        self.selectionChanged()
        
    def onError(self, failure):
        self["loading"].hide()
        self.session.open(MessageBox, f"Error: {str(failure.getErrorMessage())}", MessageBox.TYPE_ERROR)
        
    def onCancel(self):
        if self.state == "episodes":
            self.state = "seasons"
            self["title"].setText(f"{self.show_title} - Seasons")
            self["list"].setList([s['name'] for s in self.seasons])
            self["list"].show()
        else:
            self.close()
            
    def onSelect(self):
        idx = self["list"].getSelectedIndex()
        if self.state == "seasons":
            season = self.seasons[idx]
            self.loadEpisodes(season['season_number'])
        else:
            episode = self.episodes[idx]
            self.playEpisode(episode)
            
    def playEpisode(self, episode):
        ep_num = episode['episode_number']
        season_num = self.selected_season
        ep_title = f"{self.show_title} S{season_num:02d}E{ep_num:02d}"
        
        self.session.open(MessageBox, f"Searching streams for {ep_title}...", MessageBox.TYPE_INFO, timeout=2)
        
        from twisted.internet import threads
        import urllib.request, json, urllib.parse
        
        def _fetch_all_episode_streams():
            all_streams = []
            seen_hashes = set()
            
            # Torrentio Series format
            torrentio_urls = [
                f"https://torrentio.strem.fun/providers=yts,eztv,rarbg,1337x,thepiratebay,kickass/sort=seeders/stream/series/{self.imdb_id}:{season_num}:{ep_num}.json",
                f"https://torrentio.strem.fun/sort=seeders/stream/series/{self.imdb_id}:{season_num}:{ep_num}.json",
                f"https://torrentio.strem.fun/stream/series/{self.imdb_id}:{season_num}:{ep_num}.json",
            ]
            
            import ssl
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            
            for url in torrentio_urls:
                try:
                    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
                    res = urllib.request.urlopen(req, timeout=8, context=ctx)
                    data = json.loads(res.read().decode('utf-8'))
                    streams = data.get('streams', [])
                    
                    for stream in streams:
                        title = stream.get('title', '')
                        name = stream.get('name', 'Torrentio')
                        info_hash = stream.get('infoHash', '')
                        direct_url = stream.get('url', '')
                        
                        if not info_hash and not direct_url: continue
                        if info_hash in seen_hashes or direct_url in seen_hashes: continue
                        
                        stream_title = title.split('\n')[0] if '\n' in title else title
                        
                        quality_label = "?p"
                        for q in ['4K', '2160', '1080', '720', '480']:
                            if q in stream_title or q in name:
                                quality_label = q + "p" if "p" not in q and "K" not in q else q
                                break
                                
                        source = name.replace("Torrentio\n", "").strip()
                        
                        import re
                        size_match = re.search(r'([0-9.]+\s*[MGT]B)', title, re.IGNORECASE)
                        size_info = size_match.group(1) if size_match else ""
                        
                        is_french = False
                        is_arabic = False
                        upper_title = stream_title.upper().replace('/', ' ').replace('.', ' ').replace('-', ' ')
                        
                        if re.search(r'\b(FRENCH|TRUEFRENCH|VFF|VFI|VF|MULTI)\b', upper_title) or '🇫🇷' in stream_title:
                            is_french = True
                        if re.search(r'\b(ARABIC|MULTI SUBS|MULTISUB|AR|ARAB)\b', upper_title) or '🇦🇪' in stream_title:
                            is_arabic = True
                            
                        display = f"{quality_label} | {source} | {size_info}" if size_info else f"{quality_label} | {source}"
                        
                        prefix = ""
                        if is_arabic and is_french: prefix = "🇦🇪 AR/🇫🇷 VF | "
                        elif is_arabic: prefix = "🇦🇪 AR/🇬🇧 EN | "
                        elif is_french: prefix = "🇫🇷 VF | "
                        display = prefix + display
                        
                        if info_hash:
                            seen_hashes.add(info_hash)
                            trackers = "tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337&tr=udp%3A%2F%2Fopen.tracker.cl%3A1337"
                            for src in stream.get('sources', []):
                                if src.startswith("tracker:"):
                                    trackers += f"&tr={urllib.parse.quote(src.replace('tracker:', ''))}"
                            magnet = f"magnet:?xt=urn:btih:{info_hash}&dn={urllib.parse.quote(ep_title)}&{trackers}"
                            all_streams.append({'label': display, 'magnet': magnet, 'quality': quality_label})
                        elif direct_url:
                            seen_hashes.add(direct_url)
                            all_streams.append({'label': display, 'magnet': direct_url, 'quality': quality_label})
                    
                    if all_streams: break
                except Exception:
                    continue
            
            # EZTV Fallback
            if not all_streams:
                eztv_domains = ["eztvx.to", "eztv.re"]
                eztv_id = self.imdb_id.replace('tt', '')
                for domain in eztv_domains:
                    try:
                        url = f"https://{domain}/api/get-torrents?imdb_id={eztv_id}&limit=100"
                        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
                        res = urllib.request.urlopen(req, timeout=5, context=ctx)
                        data = json.loads(res.read().decode('utf-8'))
                        torrents = data.get('torrents', [])
                        if torrents:
                            for t in torrents:
                                if str(t.get('season')) == str(season_num) and str(t.get('episode')) == str(ep_num):
                                    magnet = t.get('magnet_url')
                                    if magnet:
                                        all_streams.append({'label': "EZTV Stream", 'magnet': magnet, 'quality': 'HD'})
                            break
                    except Exception:
                        continue
                        
            return all_streams
            
        def on_fetch_success(streams):
            if not streams:
                self.session.open(MessageBox, "Episode not found in Torrents.", MessageBox.TYPE_ERROR)
                return
            from .ui import QualitySelectScreen
            self.session.open(QualitySelectScreen, streams, ep_title, self.imdb_id, season=season_num, episode=ep_num)
            
        def on_fetch_error(failure):
            self.session.open(MessageBox, f"Error fetching Episode: {str(failure.getErrorMessage())}", MessageBox.TYPE_ERROR)
            
        threads.deferToThread(_fetch_all_episode_streams).addCallback(on_fetch_success).addErrback(on_fetch_error)


class GenreSelectScreen(Screen):
    skin = """
    <screen position="center,center" size="600,800" title="Select Genre" backgroundColor="#101010" flags="wfNoBorder">
        <widget name="list" position="20,20" size="560,760" font="Regular;35" itemHeight="60" scrollbarMode="showOnDemand" transparent="1" zPosition="2" />
    </screen>
    """
    
    def __init__(self, session, media_type):
        Screen.__init__(self, session)
        self.media_type = media_type
        
        # TMDB Genres
        self.movie_genres = [
            ("All", None), ("Action", 28), ("Adventure", 12), ("Animation", 16), 
            ("Comedy", 35), ("Crime", 80), ("Documentary", 99), ("Drama", 18), 
            ("Family", 10751), ("Fantasy", 14), ("History", 36), ("Horror", 27), 
            ("Music", 10402), ("Mystery", 9648), ("Romance", 10749), ("Sci-Fi", 878), 
            ("Thriller", 53), ("War", 10752), ("Western", 37)
        ]
        
        self.tv_genres = [
            ("All", None), ("Action & Adventure", 10759), ("Animation", 16), ("Comedy", 35),
            ("Crime", 80), ("Documentary", 99), ("Drama", 18), ("Family", 10751), 
            ("Kids", 10762), ("Mystery", 9648), ("News", 10763), ("Reality", 10764),
            ("Sci-Fi & Fantasy", 10765), ("Soap", 10766), ("Talk", 10767), ("War & Politics", 10768),
            ("Western", 37)
        ]
        
        self.genres = self.movie_genres if media_type == "movie" else self.tv_genres
        
        from Components.MenuList import MenuList
        self["list"] = MenuList([g[0] for g in self.genres])
        
        self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
            "ok": self.onSelect,
            "cancel": self.closeUI
        }, -1)
        
    def closeUI(self):
        self.close(None, None)
        
    def onSelect(self):
        idx = self["list"].getSelectedIndex()
        genre_name = self.genres[idx][0]
        genre_id = self.genres[idx][1]
        self.close(genre_id, genre_name)
